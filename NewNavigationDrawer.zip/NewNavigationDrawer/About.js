/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, {Component} from 'react';
import {AppState, Text, View, TouchableHighlight, Image} from 'react-native';
import WebView from 'react-native-webview';
import Styles from './Styles';

class About extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: "About",
    headerTintColor: "white",
    headerStyle: {
      backgroundColor: 'red',
    },
    headerLeft: (
      <TouchableHighlight style={Styles.menuButton} onPress={() => navigation.toggleDrawer()}>
        <Image style={{width: 44, height: 44}} source={require('./resources/menu-button.png')}/>
      </TouchableHighlight>
    ),
  });
  state = {
    appState: AppState.currentState
  };

  componentDidMount() {
    AppState.addEventListener('change', this._handleAppStateChange);
  }
  
  componentWillUnmount() {
    AppState.removeEventListener('change', this._handleAppStateChange)
  }


  _handleAppStateChange = (nextAppState) => {
    if (this.state.appState.match(/inactive|backgroud/) && nextAppState === 'active')
    {
      console.log('App has come to the foreground')
    }
    this.setState({appState: nextAppState})
  }

  render () {
    return (
      <View style={{flex:1, padding: 5}}>
        <Text style={{fontSize: 25, top: 50}}>Current state is : {this.state.appState}</Text>
        <WebView
          originWhitelist={['*']}
          source={{uri: 'https://delaplex.com/about/'}}
          style={{flex: 1}} // OR style={{height: 100, width: 100}}
        />
      </View>
    );
  }
}

export default About;