/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */
import { createStackNavigator, createAppContainer } from "react-navigation"
import SignIn from './SignIn';
import SignUp from './SignUp';
import Drawer from './routes';
import ForgotPassword from './ForgotPassword';
import {Image, View } from 'react-native';
import React, { Component } from 'react';
import NavigationDrawerStructure from './NavigationDrawerStructure';

const RootStack = createStackNavigator({
  SignIn: {
    screen: SignIn,
  },
  SignUp: {
    screen: SignUp,
  },
  ForgotPassword: {
    screen: ForgotPassword,
  },
  Drawer: {
    screen: Drawer,
    navigationOptions: {
      header: null,
    }
  }
});
console.disableYellowBox = true; // To remove yellow warning box
const App = createAppContainer(RootStack);
export default App;
