/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {Image, ActivityIndicator, StyleSheet, Alert, TouchableOpacity, Text, View, ActionSheetIOS, TouchableHighlight } from 'react-native';
import Styles from './Styles';

class Dashboard extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Dashboard",
    headerTintColor: "white",
    headerStyle: {
      backgroundColor: 'red',
    },
    headerLeft: (
      <TouchableHighlight style={Styles.menuButton} onPress={() => navigation.toggleDrawer()}>
        <Image style={{width: 44, height: 44}} source={require('./resources/menu-button.png')}/>
      </TouchableHighlight>
    ),
  });
  constructor() {
    super();
    this.state = {
      isLoading: true,
      names: [
        {
          id: 0,
          name: 'Pravin',
        },
        {
          id: 1,
          name: 'Mayur',
        },
        {
          id: 2,
          name: 'Nilesh',
        },
        {
          id: 3,
          name: 'Shwettank',
        },
        {
          id: 0,
          name: 'Prabodh',
        },
        {
          id: 1,
          name: 'Sneha',
        },
        {
          id: 2,
          name: 'Ravish',
        }
      ]
    };
  }
  _onPressShareOption() {

    this.showActionSheet()
    // this.shareOptions()
  }
  alertItemName = (item) => {
    alert(item.name)
  }
  _onPress() {
    Alert.alert(
      'New Update',
      'Please Press OK to update your App',
      [
        { text: 'Ask me later', onPress: () => this.state.isLoading = false },
        { text: 'Update data', onPress: () => this.state.isLoading = false },
        { text: 'Snooz', onPress: () => this.state.isLoading = false },
        { text: 'Cancel', onPress: () => this.state.isLoading = false, style: 'cancel' },
        { text: 'OK', onPress: () => this.state.isLoading = false },
      ],
    )
  }
  // Show action sheet
  showActionSheet() {
    ActionSheetIOS.showActionSheetWithOptions({
      options: ['Cancel', 'Remove', 'Submit'],
      submitButtonIndex: 2,
      destructiveButtonIndex: 1,
      cancelButtonIndex: 0,
    },
      (buttonIndex) => {
        if (buttonIndex === 0) {
          this.state.isLoading = false;
          console.log('Cancel action')
        } else if (buttonIndex === 1) {
          this.state.isLoading = false;
          console.log('Remove destructive action')
        } else if (buttonIndex === 2) {
          this.state.isLoading = false;
          console.log('submit action')
          this.shareOptions()
        }
      })
  }

  // Show share option menu using Actionsheet
  shareOptions() {
    ActionSheetIOS.showShareActionSheetWithOptions({
      url: 'https://code.facebook.com',
    },
      (error) => {
        console.error(error);
      },
      (success, method) => {
        var text;
        if (success) {
          text = `Shared via ${method}`;
        } else {
          text = 'You didn\'t share';
        }
        console.log(text)
        // this.setState({text});
      });
  }
  renderElement() {
    //if (this.state.isLoading) {
      <ActivityIndicator animating={true} size="large" color="#0000ff" />
    //}
  }

  render() {
    return (
      <View style={{ padding: 50 }}>
        {
          this.state.names.map((item, index) => (
            <TouchableOpacity
              key={item.id}
              style={styles.container}
              onPress={() => this.alertItemName(item)}>
              <Text style={styles.text}>
                {item.name}
              </Text>
            </TouchableOpacity>
          ))
        }
        <Text>
          Dashboard
          </Text>

        {
          this.renderElement()
        }

        {/* <TouchableOpacity
          onPress={this._onPress}
        >
          <Text style={styles.textFont}>Show Alert</Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={this._onPressShareOption.bind(this)}
        >
          <Text style={styles.textFont}>Show ActionSheet</Text>
        </TouchableOpacity> */}
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center'
  },
  textFont: {
    backgroundColor: 'white',
    fontSize: 20,
  }
});

export default Dashboard;
