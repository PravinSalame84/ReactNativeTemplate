/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 * @flow
 */

import React, {Component} from 'react';
import {Text, View} from 'react-native';
import Styles from './Styles';


export default class Details extends Component {

    static navigationOptions = ({navigation}) => ({
        title: "DETAILS",
        headerTintColor: "white",
        headerStyle: {
          backgroundColor: 'blue',
        },
    });
    

  render() {
    
    const { navigation } = this.props;
    const welcomeString = navigation.getParam('otherParam', '');

    return (
        <View style={Styles.container}>
        <Text style={Styles.welcome}>Welcome to {welcomeString} Details Screen!</Text>
        </View>
    );
  }
}