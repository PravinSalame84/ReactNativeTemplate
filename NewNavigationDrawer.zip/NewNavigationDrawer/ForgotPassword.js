/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import React, { Component } from 'react';
import { Alert, Text, AppRegistry, View, Button, Image, StyleSheet, TextInput, Actions } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';



export default class ForgotPassword extends Component {
  static navigationOptions = {
    headerTitle: 'ForgotPassword',
    headerTintColor: '#000000',
  };
  state = {
    email: 'pravin@gmail.com',
  }
  handleEmail = (text) => {
    this.setState({ email: text })
  }

  constructor() {
    super();
    // this.onPressSignUp()=this.onPressSignUp.bind();
    this.onPressReset = this.onPressReset.bind(this);
  }

  render() {
    const { navigate } = this.props.navigation;
    return (
      <View style={{ flex: 1, alignItems: 'center', marginTop:50}}>
        <Image style={styles.styleAppLogo} source={require('./resources/logo.png')}></Image>
        <View style={{marginTop:50, borderRadius: 5, paddingLeft: 5, flexDirection: 'row', borderColor: 'gray', borderWidth: 0.5, height: 45, width: '80%', alignItems: 'center' }}>
          <TextInput style={styles.styleUserNameText} placeholder='Email' autoCorrect={false} autoCapitalize = "none" underlineColorAndroid = "transparent" onChangeText = {this.handleEmail.bind()}>
          psalame@gmail.com
          </TextInput>
        </View>

        {/* Reset*/}
        <TouchableOpacity style={{ marginTop: 30, alignItems: 'center', width: 100 }} onPress={() => this.onPressReset(this.state.email)}>
          <View style={{ width: 100, borderRadius: 5, justifyContent: 'center', alignItems: 'center', height: 40, flexDirection: 'row', backgroundColor: 'deepskyblue' }}><Text style={{ color: 'white' }}>Reset</Text></View>
        </TouchableOpacity>
      </View>
    );
  }
 
  onPressReset = (email) => {

      let mailValidation = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
      if(mailValidation.test(email) === false && email.length < 6 ) {
        alert('You must enter an email address');
        return
      }
  
    console.log("clicked");
    //alert('email: ' + email + ' password: ' + pass);
    this.props.navigation.goBack()
    alert('Please check your mail '+ email);
  }
}

const styles = StyleSheet.create({
  styleUserNameText: {
    width: '90%',
    height: '100%',
    // borderBottomWidth:0.5,
    // borderBottomColor:'gray',
  },
  styleAppLogo: {
    width: 100,
    height: 100,
  },
  styleResetButton: {
    backgroundColor:'rgba(78, 169, 204, 0.8)',
    height: 45,
    alignItems: 'center',
    marginTop: 5,
    borderRadius: 2,
    width: '80%',
  },
});
