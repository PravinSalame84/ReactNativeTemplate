/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, {Component} from 'react';
import {Image, View, TouchableHighlight } from 'react-native';
import WebView from 'react-native-webview';
import Styles from './Styles';

class Help extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: "Help",
    headerTintColor: "white",
    headerStyle: {
      backgroundColor: 'red',
    },
    headerLeft: (
      <TouchableHighlight style={Styles.menuButton} onPress={() => navigation.toggleDrawer()}>
        <Image style={{width: 44, height: 44}} source={require('./resources/menu-button.png')}/>
      </TouchableHighlight>
    ),
  });
  render () {
    return (
      <View style={{flex:1, padding: 5, backgroundColor:'#111111'}}>
      <WebView
          originWhitelist={['*']}
          source={require('./resources/Konnect.pdf')}
          style={{flex: 1}} // OR style={{height: 100, width: 100}}
        />
      </View>
    );
  }
}

export default Help;