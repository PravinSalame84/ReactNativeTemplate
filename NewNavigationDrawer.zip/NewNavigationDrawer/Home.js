/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import navigationOptions from 'react-navigation';
import React, { Component } from 'react';
import { Text, AppRegistry, View, Image, StyleSheet, TouchableHighlight, Switch } from 'react-native';
import Styles from './Styles';

export default class Home extends Component {

  static navigationOptions = ({ navigation }) => ({
    title: "HOME",
    headerTintColor: "white",
    headerStyle: {
      backgroundColor: 'red',
    },
    headerLeft: (
      <TouchableHighlight style={Styles.menuButton} onPress={() => navigation.toggleDrawer()}>
        <Image style={{width: 44, height: 44}} source={require('./resources/menu-button.png')}/>
      </TouchableHighlight>
    ),
  });
  constructor(props) {
    super(props);
     this.state = {
       isSwitchOn: true,
     }
 }
  render() {
    let pic = {
      uri: 'https://upload.wikimedia.org/wikipedia/commons/d/de/Bananavarieties.jpg'
    };

    return (
      <View style={styles.container}>
      <Switch
         onValueChange = {() => this.toggleSwitch()}
         value = {this.state.isSwitchOn}/>
        <Image source={pic} style={styles.imageStyle} />
      </View>
    );
  }
  toggleSwitch = () => {
    this.setState({isSwitchOn: !this.state.isSwitchOn})
      
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#d3d3d3'
  },
  imageStyle: {
    width: 200,
    height: 120,
    borderColor: '#ff0000',
    borderRadius: 20,
    borderWidth: 5,
    opacity: 1,
  }
});