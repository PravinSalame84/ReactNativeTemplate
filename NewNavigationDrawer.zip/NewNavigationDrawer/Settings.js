/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import { KeyboardAvoidingView, TextInput, DatePickerIOS, StyleSheet, Text, View, Image, TouchableHighlight } from 'react-native';
import Styles from './Styles';

class Settings extends Component {

  static navigationOptions = ({ navigation }) => ({
    title: "Settings",
    headerTintColor: "white",
    headerStyle: {
      backgroundColor: 'red',
    },
    headerLeft: (
      <TouchableHighlight style={Styles.menuButton} onPress={() => navigation.toggleDrawer()}>
        <Image style={{width: 44, height: 44}} source={require('./resources/menu-button.png')}/>
      </TouchableHighlight>
    ),
  });
  constructor(props) {
    super(props);
    this.state = { chosenDate: new Date() };

    this.setDate = this.setDate.bind(this);
  }

  setDate(newDate) {
    this.setState({ chosenDate: newDate })
  }

  render() {
    return (
      <View style={{ padding: 50 }}>
        <Text>
          Settings
        </Text>
        <KeyboardAvoidingView style={styles.container} behavior="padding"    >
          <Image source={'./resources/home.png'} />
          <TextInput placeholder="Email" style={styles.input} />
          <TextInput placeholder="Username" style={styles.input} />
          <TextInput placeholder="Password" style={styles.input} />
          <TextInput placeholder="Confirm Password" style={styles.input} />
          <View style={{ height: 60 }} />
        </KeyboardAvoidingView>
        <DatePickerIOS date={this.state.chosenDate} onDateChange={this.setDate} />
        <Text style={{ fontSize: 20 }}>{"\n"}<Text style={{ fontWeight: 'bold' }}>Date :</Text> {this.state.chosenDate.toString()}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center'
  },
})
export default Settings;