/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import PropTypes from 'prop-types';
import React, { Component } from 'react';
import { NavigationActions } from 'react-navigation';
import { ScrollView, Text, View, Image } from 'react-native';
import styles from './SideMenu.style';


class SideMenu extends Component {

  navigateToScreen = (route) => () => {
    const navigateAction = NavigationActions.navigate({
      routeName: route
    });
    this.props.navigation.dispatch(navigateAction);
  }

  render() {
    let home_pic = {
      uri: 'https://upload.wikimedia.org/wikipedia/commons/d/de/Bananavarieties.jpg'
    };
    let profile_pic = {
      uri: 'https://i.stack.imgur.com/2ChEQ.png?s=512&g=1'
    };
    return (
      <View style={styles.container}>
        <ScrollView>

          {/* View Profile */}
          <View style={styles.profileSectionStyle}>
            <Image source={profile_pic} style={styles.profileIconStyle} />
            <Text style={styles.navItemStyle} onPress={() => this.props.navigation.toggleDrawer()}>Welcome to CR Realty</Text>
          </View>

          <View style={[styles.sectionDeviderStyle,{marginTop:30}]}>
          </View>

          {/* Home */}
          <View style={{ flexDirection: 'row', height: 45, width: '100%', alignItems: 'center', justifyContent: 'flex-start' }}>
            <Image source={require('./resources/home.png')} style={styles.menuIconStyle} />
            <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Home')}>Home</Text>
          </View>

          <View style={styles.sectionDeviderStyle}>
          </View>
          {/* Dashboard */}
          <View style={{ flexDirection: 'row', height: 45, width: '100%', alignItems: 'center', justifyContent: 'flex-start' }}>
            <Image source={require('./resources/dashboard.png')} style={styles.menuIconStyle} />
            <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Dashboard')}>Dashboard</Text>
          </View>


          <View style={styles.sectionDeviderStyle}>
          </View>
          {/* Settings */}
          <View style={{ flexDirection: 'row', height: 45, width: '100%', alignItems: 'center', justifyContent: 'flex-start' }}>
            <Image source={require('./resources/settings.png')} style={styles.menuIconStyle} />
            <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Settings')}>Settings</Text>
          </View>

          <View style={styles.sectionDeviderStyle}>
          </View>

          {/* Help */}
          <View style={{ flexDirection: 'row', height: 45, width: '100%', alignItems: 'center', justifyContent: 'flex-start' }}>
            <Image source={require('./resources/help.png')} style={styles.menuIconStyle} />
            <Text style={styles.navItemStyle} onPress={this.navigateToScreen('Help')}>Help</Text>
          </View>

          <View style={styles.sectionDeviderStyle}>
          </View>

          <View style={{ flexDirection: 'row', height: 45, width: '100%', alignItems: 'center', justifyContent: 'flex-start' }}>
            <Image source={require('./resources/about.png')} style={styles.menuIconStyle} />
            <Text style={styles.navItemStyle} onPress={this.navigateToScreen('About')}>About</Text>
          </View>

          <View style={styles.sectionDeviderStyle}>
          </View>

        </ScrollView >
        <View style={styles.sectionDeviderStyle}>
        </View>

        <View style={styles.footerContainer}>

          <View style={{ flexDirection: 'row', height: 45, width: '100%', alignItems: 'center', justifyContent: 'flex-start' }}>
            <Image source={require('./resources/logout.png')} style={styles.menuIconStyle} />
            <Text style={styles.navItemStyle} onPress={this.navigateToScreen('SignIn')}>Logout</Text>
          </View>
        </View>
      </View >
    );
  }
}

SideMenu.propTypes = {
  navigation: PropTypes.object,
};

export default SideMenu;
