export default {
    container: {
      flex: 1,
      backgroundColor: 'steelblue'
    },
    menuIconStyle: {
      width:20,
      height:20,
      marginRight:5,
      marginLeft:5,
      tintColor:'white',
    },
    profileIconStyle: {
      width:75,
      height:75,
      marginRight: 15,
      alignItems:'center',
      marginTop:10,
      marginBottom:10,
      borderRadius: 75/2
    },
    navItemStyle: {
      fontSize: 15,
      marginLeft:5,
      color:'white',
      fontWeight: 'bold',
    },
    navSectionStyle: {
      backgroundColor: 'steelblue',
      justifyContent: 'space-between',
    },
    profileSectionStyle: {
      backgroundColor: 'steelblue',
      alignItems:'center',
      marginTop:50,
    },
    sectionHeadingStyle: {
      backgroundColor : 'steelblue'
    },
    sectionDeviderStyle: {
      paddingVertical: 0.5,
      paddingHorizontal: 1,
      backgroundColor : 'darkgray'
    },
    footerContainer: {
      padding: 10,
      backgroundColor: 'red',
      opacity:0.7
    }
  };
