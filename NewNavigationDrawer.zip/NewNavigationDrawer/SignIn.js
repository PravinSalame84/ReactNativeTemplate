/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import React, { Component } from 'react';
import { Alert, Text, AppRegistry, View, Button, Image, StyleSheet, TextInput, Actions } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { api } from "./api";


export default class SignIn extends Component {
  static navigationOptions = {
    headerTitle: 'Sign In',
    headerTintColor: '#000000',
  };
  
  handleEmail = (text) => {
    this.setState({ email: text })
  }

  handlePassword = (text) => {
    this.setState({ password: text })
  }

  constructor(props) {
     super(props);
      this.state = {
        email: 'a@gmail.com',
        password: 'Admin#1',
        isSecure: true,
      }
      console.log("this is login page");
    // this.onPressSignUp()=this.onPressSignUp.bind();
    this.onPressSignUp = this.onPressSignUp.bind(this);
  }

  render() {
    const { navigate } = this.props.navigation;
    return (
      //{/* Email */ }
      < View style={{ flex: 1, alignItems: 'center', marginTop: 50 }}>

        <Image style={styles.styleAppLogo} source={require('./resources/logo.png')}></Image>
        <View style={{ marginTop: 50, borderRadius: 5, paddingLeft: 5, flexDirection: 'row', borderColor: 'gray', borderWidth: 0.5, height: 45, width: '80%', alignItems: 'center' }}>
          <TextInput style={styles.styleUserNameText} placeholder='Email' value={this.state.email} onChangeText={(text) => this.setState({ email: text })} keyboardType={"email-address"} autoCorrect={false} autoCapitalize="none" underlineColorAndroid="transparent" >
          </TextInput>
        </View>

        {/* Password */}
        <View style={{ marginTop: 5, borderRadius: 5, paddingLeft: 5, flexDirection: 'row', borderColor: 'gray', borderWidth: 0.5, height: 45, width: '80%', alignItems: 'center' }}>
          <TextInput style={styles.stylePasswordText} placeholder='Password' value={this.state.password} onChangeText={(text) => this.setState({ password: text })} autoCorrect={false} secureTextEntry={this.state.isSecure} autoCapitalize="none" underlineColorAndroid="transparent" >
          </TextInput>
          <TouchableOpacity onPress={() => this.showPassword()}>
            <Image style={{alignItems: 'center', width: 20, height: 20 }} source={require('./resources/eye.png')} ></Image>
          </TouchableOpacity>
          {/* <Button transparent style={{alignItems: 'center', width: 20, height: 20 }} source={require('./resources/eye.png')} onPress={() => this.showPassword()}/> */}
        </View>


        {/* Forgot Password */}
        
        <View style={{ marginTop: 30, width: '80%', borderRadius: 5, borderTopColor: 'gray', borderTopWidth: 0.5, justifyContent: 'flex-end', alignItems: 'flex-end', height: 20, flexDirection: 'row' }}>
          <TouchableOpacity style={{ alignSelf: 'flex-end', alignItems: 'flex-end' }} onPress={() => this.onPressForgotPassword()}>
            <View style={{ borderRadius: 5, justifyContent: 'center', alignItems: 'flex-end', height: 20, flexDirection: 'row' }}>
            <Text style={{ color: 'deepskyblue' }}>Forgot Password</Text></View>
          </TouchableOpacity>
        </View>

        <View style={{ marginTop: 30, flexDirection: 'row', height: 45, width: '100%', justifyContent: 'space-evenly' }}>
          {/* Sign In */}
          <TouchableOpacity style={{ marginTop: 0, alignItems: 'center', width: 100 }} onPress={() => this.onPressSignIn(this.state.email, this.state.password)}>
            <View style={{ width: 100, borderRadius: 5, justifyContent: 'center', alignItems: 'center', height: 40, flexDirection: 'row', backgroundColor: 'deepskyblue' }}>
            <Text style={{ color: 'white' }}>SignIn</Text></View>
          </TouchableOpacity>

          {/* <TouchableOpacity style={styles.styleUserNameText} onPress={this.navigate} title="SignUp"
          color="#241584"
          accessibilityLabel="Learn more about this SignUp button"> */}

          {/* Sign Up */}
          <TouchableOpacity style={{ marginTop: 0, alignItems: 'center', width: 100 }} onPress={() => this.onPressSignUp()}>
            <View style={{ width: 100, borderRadius: 5, justifyContent: 'center', alignItems: 'center', height: 40, flexDirection: 'row', backgroundColor: 'lightcoral' }}>
            <Text style={{ color: 'white' }}>SignUp</Text></View>
          </TouchableOpacity>
          {/* </TouchableOpacity> */}
        </View >
      </View >
    );
  }
  showPassword = () => {
    this.setState({ isSecure: !this.state.isSecure })
  }
  onPressForgotPassword = () => {

    console.log("clicked");
    this.props.navigation.push('ForgotPassword');
  }
  onPressSignIn = (email, password) => {

    let mailValidation = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
    //let mailValidation = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/ ;
    let passwordValidation = /^(?=.*\d)(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;

    if (mailValidation.test(email) === false && email.length < 6) {
      alert('You must enter an email address');
      return
    } else if (passwordValidation.test(password) === false && password.length < 6) {
      alert('Please enter valid password!')
      return
    }
    this._loginApi()

  

  }
  onPressSignUp() {
    // alert('You tapped the button!');
    console.log("clicked");
    this.props.navigation.push('SignUp');
  }  
  //Calling Login API for Login to the Server
  _loginApi = () => {
  
    let { email, password } = this.state;
    login(email, password).then(() => {
        
          this.props.navigation.push('Drawer')
              //alert('Signed In Successfully');
       
    }).catch(error => {
        console.log("login syntax error", error.message);
    })
}
}

/*****************************************************************************************/
/******************************* API Part for Networking *********************************/
/*****************************************************************************************/

export const LOGIN_REQUEST = "LOGIN_REQUEST";
export const LOGIN_SUCCESS_FAILURE = "LOGIN_SUCCESS_FAILURE";

export const loginRequest = () => {
  return {
      type: LOGIN_REQUEST
  }
}

export const loginSuccessFailure = (loginSuccessFailure) => {
  return {
      type: LOGIN_SUCCESS_FAILURE,
      loginSuccessFailure
  }
}

export const login = (Email, Password) => {

      return api.post(`Account/Login`, { "Email": "" + Email, "Password": "" + Password })
          .then(res => {
              console.log("login response", res);
              if (!res.ok) {
                  throw new Error(res.problem);
              }
              let data = getFormattedData(res);
              loginSuccessFailure(data)
             
          }).catch(error => {
              console.log("login error", error);
              loginSuccessFailure(getErrorFormattedData(error.message))
          })
  
}

export const getFormattedData = (response) => {
  console.log(response);
  let status = response && response.data ? response.data.Status : undefined
  let statusProd = response && response.data ? response.data.status : undefined
  let isSuccess = false
  if (status && status === 1) {
      isSuccess = true;
  } else if (statusProd && statusProd === 1) {
      isSuccess = true
  } else {
      isSuccess = false
  }
  let convertedRes = isSuccess ? { isSuccess, response: response.data.response, message: response.data.message } : { isSuccess, message: response.data.message ? response.data.message : response.problem }
  return convertedRes
}

const styles = StyleSheet.create({
  styleUserNameText: {
    width: '90%',
    height: '100%',
    // borderBottomWidth:0.5,
    // borderBottomColor:'gray',
  },
  stylePasswordText: {
    width: '90%',
    height: '100%',
    // borderBottomWidth:0.5,
    // borderBottomColor:'gray',
  },
  styleAppLogo: {
    width: 100,
    height: 100,
  },
  styleSignInButton: {
    backgroundColor: 'powderblue',
    height: 45,
    alignItems: 'center',
    marginTop: 5,
    borderRadius: 2,
    width: '80%',
  },
  styleSignUpButton: {
    backgroundColor: 'lightcoral',
    height: 45,
    alignItems: 'center',
    marginTop: 5,
    borderRadius: 2,
    width: '80%',
  },
});
