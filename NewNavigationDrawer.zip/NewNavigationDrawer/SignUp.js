/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
import React, { Component } from 'react';
import { Alert, Text, AppRegistry, View, Button, Image, StyleSheet, TextInput } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';

export default class SignUp extends Component {
  static navigationOptions = {
    headerTitle: 'Sign Up',
    headerTintColor: '#000000'
  };

  render() {
    return (
      < View style={{ flex: 1, alignItems: 'center', marginTop: 50 }}>

        <Image style={styles.styleAppLogo} source={require('./resources/logo.png')}></Image>
        <View style={{ marginTop: 50, borderRadius: 5, paddingLeft: 5, flexDirection: 'row', borderColor: 'gray', borderWidth: 0.5, height: 45, width: '80%', alignItems: 'center' }}>
          <TextInput style={styles.styleUserNameText} placeholder='Email' autoCorrect={false} autoCapitalize="none" underlineColorAndroid="transparent" onChangeText={() => this.handleEmail()}>
            psalame@gmail.com
            </TextInput>
        </View>

        {/* Password */}
        <View style={{ marginTop: 5, borderRadius: 5, paddingLeft: 5, flexDirection: 'row', borderColor: 'gray', borderWidth: 0.5, height: 45, width: '80%', alignItems: 'center' }}>
          <TextInput style={styles.stylePasswordText} placeholder='Password' autoCorrect={false} secureTextEntry={true} autoCapitalize="none" underlineColorAndroid="transparent" onChangeText={() => this.handlePassword()}>
            prrasin@123
            </TextInput>
          <Image style={{ width: 20, height: 20 }} source={require('./resources/eye.png')}></Image>
        </View>

        {/* Password */}
        <View style={{ marginTop: 5, borderRadius: 5, paddingLeft: 5, flexDirection: 'row', borderColor: 'gray', borderWidth: 0.5, height: 45, width: '80%', alignItems: 'center' }}>
          <TextInput style={styles.stylePasswordText} placeholder='Password' autoCorrect={false} secureTextEntry={true} autoCapitalize="none" underlineColorAndroid="transparent" onChangeText={() => this.handlePassword()}>
            prrasin@123
            </TextInput>
          <Image style={{ width: 20, height: 20 }} source={require('./resources/eye.png')}></Image>
        </View>

        <View style={{ marginTop: 25, flexDirection: 'row', height: 45, width: '100%', justifyContent: 'space-evenly'}}>

          {/* SignUp Button */}
          <TouchableOpacity style={{ marginTop: 5, alignItems: 'center', width: 100 }} onPress={() => this.onPressSignUp()}>
            <View style={{ width: 100, borderRadius: 5, justifyContent: 'center', alignItems: 'center', height: 40, flexDirection: 'row', backgroundColor: 'deepskyblue' }}><Text style={{ color: 'white' }}>SignUp</Text></View>
          </TouchableOpacity>

          {/* Cancel Button */}
          <TouchableOpacity style={{ marginTop: 5, alignItems: 'center', width: 100 }} onPress={() => this.props.navigation.goBack()}>
            <View style={{ width: 100, borderRadius: 5, justifyContent: 'center', alignItems: 'center', height: 40, flexDirection: 'row', backgroundColor: 'lightcoral' }}><Text style={{ color: 'white' }}>Cancel</Text></View>
          </TouchableOpacity>

        </View>
      </View>
    );
  }
  onPressBack() {
    Alert.alert('You tapped the button!')
    this.props.navigation.navigate("SignIn");

  }
  onPressSignUp = () => {

    Alert.alert('Signed Up Successfully!')
    this.props.navigation.push('Drawer');
  }
}

const styles = StyleSheet.create({
  styleUserNameText: {
    height: 40,
    width: '80%',
  },
  stylePasswordText: {
    height: 40,
    width: '90%',
  },

});
