import {StyleSheet} from 'react-native'
import React , { Component } from 'react';

const Style = StyleSheet.create({

container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  buttonStyle: {
    marginTop: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  welcomeText: {
    fontSize: 20,
  },
  menuButton: {
    width: 44,
    height: 44,
    alignItems:"center",
  },
});

export default Style