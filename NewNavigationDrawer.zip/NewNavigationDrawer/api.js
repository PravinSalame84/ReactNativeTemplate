// import axios from "axios";
import { create } from 'apisauce'
// prod url
// const base_url = "https://saturn.megasus.global/api/"
// export const Forte_Url = "https://api.forte.net/v3/organizations/org_370002/locations/loc_227838/"
//const forteHeader = {"Authorization" : "Basic YTM2Zjg2ZTQ1YTY2ZjY5MzU4MzYzZTM5OWQxYzBmYTY6ODEzMTM3Mzg4Y2Q1ZWQxOWE3Y2IwMjE0ZGUzYTg2YzU=", "X-Forte-Auth-Organization-Id" : "org_370002", "Accept" : "application/json"}


// local url
export const base_url = "http://10.1.1.12:88/api/"

// Sandbox
export const Forte_Url = "https://sandbox.forte.net/api/v3/organizations/org_368812/locations/loc_226377/"
const forteHeader = { "Authorization": "Basic MGJjZjE0MTZjYmYxMTE1NzhjNzUzZTM5MTIxMzJkNTU6YTVlODFlNzBiMTJjNmM0MTFmZjZkYjljMDY0ZDFjYWM=", "X-Forte-Auth-Organization-Id": "org_368812", "Accept": "application/json" }


export const api = create({
    baseURL: base_url,
    headers: {
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
    },
})

export const forteAPI = create({
    baseURL: Forte_Url,
    headers: forteHeader,
})