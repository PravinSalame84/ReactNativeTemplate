import Home from './Home';
import Dashboard from './Dashboard';
import Settings from './Settings';
import Help from './Help';
import About from './About';
import SideMenu from './SideMenu';
import { createDrawerNavigator, createStackNavigator } from 'react-navigation';
import {Image, View } from 'react-native';
import React, {Component} from 'react';
import DetailsScreen from './Details';

const HomeNavStack = createStackNavigator({
  ScreenOne: {screen: Home},
  DetailScreen: {screen: DetailsScreen},
});
const DashboardNavStack = createStackNavigator({
  ScreenOne: {screen: Dashboard},
  DetailScreen: {screen: DetailsScreen},
});

const SettingsNavStack = createStackNavigator({
  ScreenOne: {screen: Settings},
  DetailScreen: {screen: DetailsScreen},
});

const HelpNavStack = createStackNavigator({
  ScreenOne: {screen: Help},
  DetailScreen: {screen: DetailsScreen},
});
const AboutNavStack = createStackNavigator({
  ScreenOne: {screen: About},
  DetailScreen: {screen: DetailsScreen},
});

const Drawer = createDrawerNavigator(
  {
    Home: {
      screen: HomeNavStack,
      name: 'Home',
    },
    Dashboard: {
      screen: DashboardNavStack,
      name: 'Dashboard',
    },
    Settings: {
      screen: SettingsNavStack,
      name: 'Settings',
    },
    Help: {
      screen: HelpNavStack,
      name: 'Help',
    },
    About: {
      screen: AboutNavStack,
      name: 'About',
    }
  },
  {
    initialRouteName: 'Home',
    contentComponent: SideMenu,
    drawerWidth: 300
  },
);
export default Drawer;

//below is to directly show the drawer without using stack navigation
// const Routes = createAppContainer(RootStack);
// export default Routes;
